---
name: cabinet-designer-change-workflow
description: Diagnose, implement, test, and verify Cabinet Dealz regular Designer changes without confusing them with Continuous Wall Builder or unverified live deployments. Use when fixing Designer countertop, cabinet placement, crown, plan/3D parity, loading-state, or saved-layout regressions; also use when producing before/after proof or checkpointing Designer edits.
---

# Cabinet Dealz Designer Change Workflow

Use this **execution workflow**, not as a source of cabinet geometry rules. First read `/home/ubuntu/skills/cabinet-design-rules/SKILL.md` for the user's placement/rendering requirements. Inspect the actual attached webdev project; never assume the project path, source layout, deployment, or test baseline is unchanged. Follow any newer user instructions over illustrative examples here.

## 1. Lock the scope and establish a baseline

1. Restate the observable problem and pass criteria. Distinguish **regular Designer**, **Continuous Wall Builder**, **Floor Plan**, **elevation**, and **3D**. Do not change a working tool merely because a similarly named renderer exists elsewhere.
2. Open the attached managed webdev project using `webdev_init_project` when attached. Check the current branch, checkpoint, `git status`, relevant project notes, and the user-supplied screenshot. Treat a screenshot as a symptom, not proof of which algorithm failed. Read files and project-specific skills before planning edits.
3. Find the *same actual saved layout* or build a minimal faithful fixture with room dimensions, wall/run IDs, cabinet positions/rotation, openings, island/pony walls, material choices, and any load-time automatic fillers. Saved drafts can be scoped by owner/email and normalized on restore: verify the **restored browser state**, not only the raw JSON. Never overwrite the user's saved design while testing; use an isolated test identity/local draft or read-only fixture.
4. Capture before images in each affected view and record the build/version, source layout, viewport, camera, and URL origin. A local render is not live-site proof. If the user explicitly asks for a branch-only experiment, do not merge, deploy, or checkpoint it to main.

## 2. Diagnose the owning layer before writing code

- **Placement/restore:** `client/src/pages/DesignTool.tsx`, `client/src/lib/design.ts`, and focused placement helpers.
- **Plan / elevation:** `client/src/components/design/PlanCanvas.tsx`, `ElevationView.tsx`.
- **3D:** `client/src/components/design/InteractiveRoom3D.tsx`; inspect per-cabinet vs shared-surface suppression and world transforms.
- **Shared countertop geometry:** `countertopSurfaces`, polygon-to-surface conversion, run grouping/void fill, and any peninsula/free-standing builders in `client/src/lib/`.
- **Wall Builder:** trace its actual placement and polygon functions only if parity or reuse is requested. Preserve its behavior unless the user specifically authorizes changing it.

Measure the cabinet footprints, countertop world polygons, 3D mesh positions/elevations, and visibility separately. An absent polygon, incorrect polygon dimensions/rotation, back-face winding, and an omitted/suppressed mesh require different fixes. For voids, include tiny gaps, 45° returns, load-time fitted fillers, dishwasher support, and real no-countertop breaks (e.g., ranges). Never fill empty space indiscriminately or add floating countertop without evidence of intended support. Check custom-wall, standard-room, and free-standing branches independently.

## 3. Make the smallest reversible change

Write a failing regression using the actual fixture or a minimal reproduction, then change the shared owning function when appropriate. Keep pricing/catalog, save data, other tools, and geometry unrelated to the request unchanged. Prefer a dedicated test branch/worktree for potentially destructive hypotheses; compare before/after in identical camera and layout. Avoid speculative refactors and commits containing temporary injection scripts, debug tests, customer data, screenshots in `client/public`, or modified project configuration.

For an asynchronous-feeling rendering indicator, read [countertop-loading.md](references/countertop-loading.md). A spinner is not proof that synchronous work became asynchronous; verify it actually paints **before** the expensive commit and clears **after** the new scene frame.

## 4. Validate at three levels

1. Run `npx tsc --noEmit`, `pnpm build`, and focused tests for the edited path. Run the full Vitest suite when practical. Establish a pre-change baseline on an unchanged branch/worktree; use `scripts/compare_vitest_failures.py` to distinguish newly failing tests from unrelated pre-existing or flaky external-service tests. Preserve both commands' exit codes and inspect every new failure before calling the change complete.
2. In a browser, load the same saved fixture, perform the **actual user interaction** (drag/nudge, select, resize, switch view), and inspect Floor Plan, elevation, and 3D as relevant. Check no console errors; measure output polygons or rendered meshes if a screenshot is ambiguous. For a loading badge, verify appearing and clearing on a real geometry update, correct accessibility semantics, nonblocking pointer behavior, and reduced-motion behavior.
3. If live proof is requested, wait for the new build and verify on the requested **production origin** with the same layout, viewport and camera; do not substitute a dev preview. Inspect side-by-side proof critically, including gaps/seams, stray pieces, orientation, and cabinet coverage. Do **not** say “fixed live” just because a checkpoint saved or a chunk hash changed; confirm the actual browser render. If verification fails, report the remaining defect honestly instead of inventing a passing screenshot.

## 5. Checkpoint and hand off

For a managed webdev project, save a `webdev_save_checkpoint` **only after** verifying the intended change; include the returned `manus-webdev://` version in the final reply. Respect any branch-only or no-deploy instruction. If the user's custom rule requires confirmation before public publishing, treat checkpoint/preview and live deployment as distinct actions. Report what changed, which views and layout were checked, any baseline failures, and any remaining limitations in plain language. When the user requested screenshots, deliver labeled before/after or plan/3D pairs with their actual origin and build; never call a local screenshot live.
