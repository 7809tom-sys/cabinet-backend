---
name: cabinetdealz-one-engine-parity
description: Prove or repair behavior parity between the CabinetDealz 3D Designer standard room and Continuous Wall Builder. Use when cabinets, walls, fillers, dimensions, countertops, takeoffs, or controls drift between the two tools.
---

# CabinetDealz One-Engine Side-by-Side Parity

The Standard Designer and Continuous Wall Builder are one system. Normal cabinet behavior must match exactly.

## Scope rules

- Read `cabinet-design-rules` first.
- Audit before changing code; identify every tool-specific branch and whether it is needed input or an avoidable behavior fork.
- Use shared modules (`design.ts`, shared renderers, PlanCanvas, InteractiveRoom3D). Do not add Wall Builder-only fixes for normal cabinets.
- Do not change catalog, prices, or invoices while fixing geometric parity unless explicitly requested.

## Side-by-side matrix

| Dimension | Verify |
|---|---|
| Placement | cabinet ID/code, dimensions, wall ID, offset, rotation, 1/8-in. seat |
| Controls | catalog drop, snap, drag, Rotate, nudge, resize |
| Corners | 90-degree and 45/135-degree base, wall, tall, and filler behavior |
| Surfaces | countertop runs, miter/infill, no unsupported slabs |
| Takeoff | price key, material line, trim totals, filler billing |
| Views | Floor Plan, elevation, 3D, photo render |

## Workflow

1. Seed one documented fixture with cabinet IDs and wall geometry.
2. Place identical cabinets through real catalog clicks in standard and custom-wall rooms.
3. Read shared state and produce a numeric parity table; do not compare screenshots only.
4. Move mismatched normal behavior into the shared engine and add regression tests against both rooms.
5. Run focused tests, TypeScript, build, local real-click proof, checkpoint, deployment detection, and cache-busted live proof.
6. Save paired screenshots/JSON with the deployed bundle and append the ledger.

A mismatch in any row means parity is not complete.
