#!/usr/bin/env python3
"""Wait for a marker to appear in a published CabinetDealz Designer asset graph."""

import argparse
import json
import re
import sys
import time
from urllib.parse import urljoin

import requests


def asset_names(source: str, prefix: str) -> list[str]:
    return sorted(set(re.findall(rf"{re.escape(prefix)}-[A-Za-z0-9_-]+\.js", source)))


def fetch(base: str, path: str) -> str:
    return requests.get(
        urljoin(base.rstrip("/") + "/", path.lstrip("/")),
        headers={"Cache-Control": "no-cache", "Pragma": "no-cache", "User-Agent": "Mozilla/5.0"},
        timeout=45,
    ).text


def inspect(base: str, marker: str) -> dict:
    html = fetch(base, f"/?designer-deploy={int(time.time())}")
    indexes = sorted(set(re.findall(r"/assets/index-[A-Za-z0-9_-]+\.js", html)))
    index_source = "\n".join(fetch(base, path) for path in indexes)
    designer = asset_names(index_source, "DesignTool")
    renderer = asset_names(index_source, "InteractiveRoom3D")
    candidates = [f"/assets/{name}" for name in designer + renderer]
    candidate_source = "\n".join(fetch(base, path) for path in candidates)
    return {
        "base": base.rstrip("/"),
        "checkedAtEpoch": int(time.time()),
        "indexBundles": [path.rsplit("/", 1)[-1] for path in indexes],
        "designerBundles": designer,
        "rendererBundles": renderer,
        "marker": marker,
        "markerFound": marker in index_source or marker in candidate_source,
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", required=True, help="Published site base URL")
    parser.add_argument("--contains", required=True, help="Stable source marker expected in an index, Designer, or renderer chunk")
    parser.add_argument("--timeout", type=int, default=900, help="Maximum seconds to wait")
    parser.add_argument("--interval", type=int, default=15, help="Seconds between attempts")
    parser.add_argument("--output", help="Write final observation JSON here")
    args = parser.parse_args()

    deadline = time.time() + max(1, args.timeout)
    last: dict | None = None
    while time.time() < deadline:
        try:
            last = inspect(args.base, args.contains)
            print(json.dumps(last, sort_keys=True), flush=True)
            if last["markerFound"]:
                if args.output:
                    with open(args.output, "w", encoding="utf-8") as file:
                        json.dump(last, file, indent=2)
                        file.write("\n")
                return 0
        except requests.RequestException as error:
            print(f"retry: {type(error).__name__}: {error}", file=sys.stderr, flush=True)
        time.sleep(max(1, args.interval))

    if args.output and last is not None:
        with open(args.output, "w", encoding="utf-8") as file:
            json.dump(last, file, indent=2)
            file.write("\n")
    print(f"Timed out waiting for marker: {args.contains}", file=sys.stderr)
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
