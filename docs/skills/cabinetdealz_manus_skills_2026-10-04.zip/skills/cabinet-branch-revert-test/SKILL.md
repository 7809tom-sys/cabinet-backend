---
name: cabinet-branch-revert-test
description: Safely test whether one suspect Cabinet Dealz git commit caused a Designer regression by reverting it only in an isolated branch/worktree, comparing pinned baseline and candidate evidence, and stopping before merge or deployment. Use when investigating a requested commit revert (including a short hash such as 350203658), testing a causal hypothesis without changing the main checkout, or producing before/after proof for authorization review.
---

# Cabinet Dealz isolated revert test

Use this skill for **evidence gathering only**. Do not merge, deploy, checkpoint, rewrite history, or alter the user's main checkout. Do not execute a revert merely because a commit was mentioned; first obtain the requested target, fixture, and test scope, and end with an explicit authorization hold.

## 1. Freeze scope and prove the starting point

1. Identify the actual attached Cabinet Dealz repository and its owning checkout. Read project notes and applicable project instructions, but do not edit them. Keep this workflow separate from cabinet geometry rules; load those only when interpreting a geometry symptom.
2. In the original checkout, record:
   - `git status --short --branch` and require a clean worktree (stop if tracked or relevant untracked changes exist).
   - current branch, `git rev-parse --show-toplevel`, `git rev-parse HEAD`, remote/upstream, and tool/runtime versions used by tests.
   - the requested suspect commit as an **exact full hash**: resolve a short input with `git rev-parse --verify '<input>^{commit}'`, then confirm it belongs to the intended history with `git merge-base --is-ancestor <hash> <starting-head>` (or explain why another ancestry relation is intended).
   - `git show --no-ext-diff --stat --summary <hash>` and the parent(s); inspect the diff and note affected paths.
3. Refuse ambiguous targets: do not guess among multiple objects, silently substitute a nearby commit, or use a moving remote ref. Save the starting HEAD and resolved hash in the test record.

## 2. Create a disposable candidate worktree

1. Choose a new branch name that identifies the experiment and resolved commit, without touching the current branch. Create a separate worktree outside the original checkout, for example:
   ```bash
   git worktree add --detach /tmp/cabinet-revert-<id> <starting-head>
   git -C /tmp/cabinet-revert-<id> switch -c test/revert-<short-hash>-<slug>
   ```
   Use a project-approved disposable location if `/tmp` is unsuitable. Verify both paths, branches, and HEADs; never use `git reset`, `git checkout` over user changes, or a shared worktree.
2. Keep the original checkout untouched throughout. Record worktree path, branch, starting HEAD, resolved suspect hash, and cleanup instructions. Do not create a commit unless the test procedure explicitly requires a local candidate commit; an uncommitted revert is preferred for a no-history experiment.
3. Before changing the candidate, run the same baseline commands there and capture exit codes and outputs. Install or build only in the isolated worktree using the repository's documented package-manager lockfile and commands.

## 3. Pin a reproducible visual/functional fixture

1. Use the same saved layout or a minimal faithful fixture for baseline and candidate. Pin fixture identity/content, room and wall dimensions, cabinet positions/rotations, openings, fillers, countertop/material choices, viewport, browser/runtime, URL origin, and build configuration. Do not use customer data or overwrite a saved design.
2. Pin the 3D camera exactly: position, target/look-at, up vector, field of view/orthographic scale, canvas size/device pixel ratio, lighting/material settings, and view mode. For plan/elevation, pin viewport bounds and scale as well. Record fixture checksum or canonical JSON where possible.
3. Capture labeled baseline proof before the revert: screenshots or measurements for every affected view, plus console/network errors and relevant geometry/mesh assertions. A local render is not live-site proof.

## 4. Apply and analyze exactly one revert

1. In the candidate worktree only, run `git revert --no-commit <resolved-full-hash>`. If the commit has multiple parents, stop and determine the intended mainline; do not guess `-m`.
2. On conflict, do not auto-resolve. Record conflicted files with `git status`, inspect conflict markers and the original commit/parent diffs, and classify each conflict. Abort with `git revert --abort` if the conflict cannot be resolved without introducing unrelated edits. If a resolution is authorized for test setup, document every compatibility repair and keep it minimal.
3. Distinguish **test-only compatibility repairs** (for example, a lockfile/toolchain or fixture adaptation needed to run the historical code) from evidence that the suspect commit caused the regression. Repairs are not causal proof; report them separately and, when possible, test the unmodified historical state or a second control.
4. Never merge the candidate, push it, save a checkpoint, deploy it, or publish it. Do not execute this procedure now when the request is only to create this skill.

## 5. Run paired tests and inspect causality

1. Run the identical baseline and candidate commands: typecheck/build, focused regression tests, relevant full suite when practical, and browser interaction tests. Preserve command lines, environment versions, exit codes, durations, and all new failures. Compare against the unchanged baseline; separate pre-existing, flaky, environment, and compatibility failures from candidate-only failures.
2. Load the pinned fixture and perform the real user interaction. Compare plan, elevation, and 3D only where relevant; inspect console errors and measure footprints, polygons, transforms, visibility, seams, gaps, and countertop/cabinet coverage rather than relying on screenshots alone.
3. Capture candidate proof with the identical fixture, camera, viewport, origin, and labels. Align before/after images and retain machine-readable measurements. A passing test or visual difference alone does not establish causality; state whether the revert removes the symptom, introduces regressions, or is inconclusive.
4. If the revert cannot be tested cleanly, report the exact blocker and do not claim the commit was causal. Clean up only the disposable worktree after preserving the test record and proof, and verify the original checkout remains at its recorded clean HEAD.

## 6. Report and hold for authorization

Deliver a concise report containing: original clean status, starting HEAD, exact suspect hash and ancestry, isolated worktree/branch, revert and conflict outcome, compatibility repairs, pinned fixture/camera, baseline-versus-candidate commands and results, before/after proof paths and origins, regressions/limitations, and cleanup status. Conclude with one of **supports causal hypothesis**, **does not support**, or **inconclusive**.

End with an explicit hold: **do not merge or deploy until the user separately authorizes the next action**. If authorization arrives later, re-check status and hashes before any merge/deployment workflow; this skill itself never performs that action.
