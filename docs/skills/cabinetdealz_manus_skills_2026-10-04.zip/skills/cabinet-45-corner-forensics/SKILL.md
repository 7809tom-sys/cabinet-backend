---
name: cabinet-45-corner-forensics
description: Evidence-first diagnosis of 45-degree corner, cabinet seating, and countertop regressions in the regular Cabinet Dealz Designer. Use when a 45° run shows gaps, seams, floating or missing slabs, incorrect plan/3D orientation, bad reloads, or unexplained differences from Continuous Wall Builder, especially when tracing suspect commits such as 3502036585.
---

# 45° corner forensics

Diagnose before proposing changes. Work read-only in `/home/ubuntu/cabinet-dealz`; do not edit, deploy, import data, save checkpoints, or recommend speculative live code changes. Do not alter Continuous Wall Builder while using it as the reference implementation. Do not duplicate general cabinet placement rules; use this skill for evidence collection, causal narrowing, and proof.

## Workflow

1. **Define the reproduction and invariant.** Record tool, layout identifier, cabinet UIDs/SKUs, rotations, wall IDs, room geometry, expected miter/overhang, and the exact symptom. State whether expected behavior is parity with a Wall Builder layout or a standalone free-standing run. Do not treat “yesterday was good” as evidence.
2. **Capture a clean baseline.** Preserve raw saved-layout JSON (or a redacted structural extract) before opening the UI. Record browser/local-storage/session restoration separately, including auto-generated fillers, repaired placements, and reload sweeps that remove overlaps. Hash or timestamp artifacts; never mutate the saved design merely to obtain proof.
3. **Map history, not guesses.** Inspect `git log`, `git show`, and `git blame` around suspect commit `3502036585` (or abbreviated `350203658`) and the first commits changing the affected path. Compare last known-good and first known-bad observable behavior, not calendar recency. Use `git bisect` only with a deterministic reproduction/test; otherwise build a commit matrix and label every result observed, inferred, or unknown. Include rollback/checkpoint and docs-only proof commits.
4. **Trace placement and restoration.** Follow saved JSON → normalization/repair → collision/removal sweep → Designer placement/drop/drag/rotate/nudge → derived wall or synthetic-run seating. Check `wallId`, `wallOffset`, rotation convention, AABB origin versus rotated-body center, depth-dependent 45° corner hold, wall/island/peninsula flags, and whether auto fillers are saved members or generated restoration artifacts. Compare raw and restored records field-by-field.
5. **Trace cabinet polygons.** Inspect plan-space body polygons, rotated AABBs, neighbour adjacency, true-body intersection, front/back edges, and shared corner point. Distinguish genuine overlap/gap from AABB-only collision or a display transform. Verify flush seating to both neighbours under one coordinate and rotation convention; never infer it from a screenshot alone.
6. **Trace countertop surfaces.** In `client/src/lib/design.ts`, follow `countertopSurfaces()` and the custom-wall/free-standing path; inspect `countertopSurfaceFromWorldPolygon()`, `countertopSurfacePlanPolygon()`, contiguous-run merging, miter construction, run/member IDs, and wall fallback selection. Determine whether the surface is absent, split, mis-sized, attached to the nearest wall, or intentionally suppressed because no cabinet is physically covered. Compare raw surface polygons and metadata with cabinet polygons and expected Wall Builder surfaces.
7. **Trace mesh realization.** Follow surfaces into `InteractiveRoom3D` and standard/shared countertop helpers. Record extrusion dimensions, transform center, plan-to-Three rotation sign, translation, face winding/normals, back/front ordering, and coverage tests suppressing cabinet tops or slabs. A correct plan polygon can still yield a mirrored, culled, shifted, or floating mesh; inspect transformed vertices/normals. Check toe-kick/support generation separately.
8. **Cross-check views and reference path.** Compare the same normalized layout in Floor Plan, elevation/2D, 3D, and Materials/parts where applicable. Build equivalent Wall Builder geometry and follow `wallBuilderRoomGeometry` → custom wall/run frame → `wallPlacementAt` → measured-wall countertop miter path as reference, without changing that code. For free-standing runs, verify whether Designer reuses that engine or diverges.
9. **Localize the first bad commit.** Run focused tests and a deterministic browser/render harness at candidate commits. For each commit, save raw layout, restored state, cabinet polygons, surfaces, mesh diagnostics, console errors, and screenshots. Mark the earliest commit where a specific invariant fails. If a build cannot run, record the blocker; never assume a baseline.
10. **Separate cause from symptom.** Classify the primary fault as saved data, restoration/auto-filler mutation, seating/rotation, polygon/collision, surface construction, mesh transform/winding, or screenshot/environment. Explain the causal chain and falsifying evidence. Treat floating slabs, seams, missing tops, and apparent gaps as symptoms until lower-level artifacts identify their source. Do not propose a code patch or live fix in the forensic report.

## Evidence checklist

- **Identity:** commit SHA, branch, timestamp, build/bundle, layout ID, tool, viewport/camera.
- **Saved vs restored:** raw JSON hash; restored JSON hash; generated UIDs/fillers; changed fields.
- **Geometry:** cabinet polygons/AABBs; rotations; wall/run membership; neighbour distances; intersection results; miter/shared-vertex coordinates.
- **Surfaces:** complete polygon vertices, AABB, rotation, run/member IDs, coverage decisions, expected-vs-actual diff.
- **Meshes:** transformed vertices, normals/winding/culling, extrusion height, transform/rotation, and cabinet-top suppression.
- **Proof:** side-by-side same-layout screenshots for Designer and Wall Builder plus a machine-readable manifest and zero-error console/network capture. Preserve originals before annotation.

## Report format

```markdown
# 45° corner forensic report
## Reproduction and invariant
## Evidence matrix
| Stage | Expected | Observed | Artifact | Confidence |
## First failing commit
## Causal diagnosis
## Falsified alternatives
## Screenshot proof
## Limits and unknowns
```

Use confidence labels (`observed`, `derived`, `inferred`, `unknown`). Link or provide absolute paths to every artifact. Report no live code change unless a separate authorized implementation task explicitly requests one.
