---
name: cabinetdealz-safe-revert-branch-test
description: Safely test whether a CabinetDealz regression was introduced by a previous change without disrupting the active workspace or publishing a rollback. Use for revert experiments, historical comparison, or regression isolation.
---

# CabinetDealz Safe Revert Test on a Branch

Use a disposable Git worktree or branch experiment. Never use a revert test to modify production, delete user data, alter prices, or overwrite the active workspace.

## Procedure

1. Record `git status --short`, HEAD, checkpoint, target commits, exact symptom, fixture, and expected historical behavior.
2. If the main worktree is dirty, do not checkout or reset it. Create a separate worktree from a baseline:
   ```bash
   git worktree add /tmp/cabinetdealz-revert-<issue> <baseline>
   ```
3. Cherry-pick or `git revert --no-commit <commit>` only inside the disposable worktree. Do not guess through conflicts; record them as evidence.
4. Run the smallest decisive focused test and seeded local browser fixture. Compare source, DOM, geometry JSON, and screenshots with the current result.
5. Classify the finding as causal, correlated, or inconclusive; identify the exact hunk/path when causal.
6. Preserve evidence outside the temporary worktree, remove the worktree, and do not merge/push/deploy from the experiment.

## Required report

Include baseline SHA, experiment SHA, commands/tests, before/after symptom, evidence, and recommendation. A revert experiment is diagnosis only; obtain scope before making a product fix.
