# CabinetDealz Manus Skills — 2026-10-04

| Skill | Purpose |
|---|---|
| cabinet-design-rules | User-owned CabinetDealz placement, geometry, and rendering rules. |
| cabinetdealz-shared-designer-delivery | Shared-engine delivery, testing, checkpoint, deployment, and evidence workflow. |
| cabinetdealz-peninsula-wizard | Selected-cabinet peninsula, 45-degree return, filler, support, and split-level-bar workflow. |
| cabinetdealz-45-corner-forensics | Measured diagnosis and repair process for 45/135-degree corners. |
| cabinetdealz-safe-revert-branch-test | Disposable worktree procedure for regression-isolation revert experiments. |
| cabinetdealz-one-engine-parity | Standard Designer versus Continuous Wall Builder parity methodology. |
| cabinetdealz-catalog-spreadsheet-import | Staged, audited distributor catalog spreadsheet import process. |
