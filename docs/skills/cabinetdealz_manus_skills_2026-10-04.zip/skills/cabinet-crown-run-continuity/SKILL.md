---
name: cabinet-crown-run-continuity
description: Diagnose and verify Cabinet Dealz Designer crown molding geometry around refrigerator bridges, tall cabinets, staggered uppers, and glass stacks. Use when crown clips through a cabinet, appears below a cabinet top, fails to meet adjacent crown, or Floor Plan/elevation top badges disagree with 3D.
---

# Cabinet Dealz crown-run continuity

Use alongside `cabinet-design-rules` for dimensions and `cabinet-designer-change-workflow` for test/live-proof protocol. This skill addresses **regular Designer crown**, not catalog pricing. Preserve existing saved layouts and Continuous Wall Builder unless a separate request covers them.

## Non-negotiable geometry

- A crown segment sits **on the actual top of its cabinet/stack**, never at a lower neighbor's top while passing through that cabinet. A fridge bridge may receive crown on its own top when it is the uppermost element of its stack; crown is not a mid-height decorative rail through it.
- Crown at a common top elevation meets cleanly across adjoining cabinet bodies. Clip returns and miters at neighbors; leave no overlapping or disconnected pieces.
- Different top elevations form distinct runs. A taller cabinet is a *physical blocker* for a shorter neighbor's crown return even if the taller cabinet itself is not eligible for crown. Conversely, do not suppress an eligible bridge simply because its top reaches the ceiling.
- For a stack of wall cabinets/glass stackers, identify the uppermost cabinet in the column before applying crown. Do not place an extra run at a buried lower top.

## Trace and reproduce

1. Read current `client/src/lib/design.ts` crown classification (`isCrownEligibleCabinet`, `crownEligibleCabinets`, `crownBlockingCabinets`, `elevationBox`) and `client/src/components/design/InteractiveRoom3D.tsx` crown perimeter/clipping. Check current names; they may change.
2. Reproduce with a saved fridge, bridge, neighboring wall cabinet, and tall pantry. Record `uid`, wall, span, `mountBottom`, height, resolved cabinet top, crown rail top, and cabinet footprint. Test equal-height and unequal-height cases, including a bridge below a taller pantry. Distinguish a crown piece from light rail, drywall, or a countertop in the screenshot.
3. Compute eligible segments and **all physical blockers** separately, then inspect resulting front/return intervals and miter endpoints. Crown must not intersect any cabinet body at a lower elevation. Compare the materialized 3D mesh, not just abstract segments.
4. Use crown-top run badges in Floor Plan and elevation as a diagnostic: group adjacent cabinets by actual top height, label each run, and expose mismatched top elevations before reviewing 3D. A badge does not substitute for validating 3D clipping.

## Regression and release gate

- Add focused tests for a fridge bridge at its top, an adjacent equal-top wall cabinet with a merged rail, a lower bridge beside a higher pantry with no penetration, and an upper stack with only top crown. Keep a fixture with saved placement semantics and test restoration where relevant.
- Run `npx tsc --noEmit`, focused `crownStack.test.ts`, `SavedKitchenCornerAndBridge.test.ts`, `DesignerTrimContinuity.test.ts`, `crownTopRuns.test.ts`, and compare the full suite against an unchanged baseline.
- Capture plan/elevation badges and 3D proof for the **same** restored design. For live claims, inspect the actual requested production origin and version, not merely local preview or a checkpoint. Stop and report if a segment still cuts through a cabinet or does not merge.
