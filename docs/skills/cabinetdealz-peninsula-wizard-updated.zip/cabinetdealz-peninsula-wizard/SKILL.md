---
name: cabinetdealz-peninsula-wizard
description: Build or modify CabinetDealz Peninsula Wizard flows. Use when a user wants to choose peninsula cabinet runs, 45-degree turns, fillers, pony-wall supports, or counter-height versus split-level bar treatment.
---

# CabinetDealz Peninsula Wizard

Use this skill for a guided peninsula layout. Keep the 3D Designer and Continuous Wall Builder on the same shared geometry engine; never create a Wall Builder-only layout path.

## Guardrails

- Read `cabinet-design-rules` and project full-stack guidance before code changes.
- Use selected-line catalog records only. Do not invent cabinet codes, widths, filler stock, prices, or 3D shapes.
- Do not silently replace a requested cabinet with another size.
- No price changes as part of a wizard feature.
- A 45-degree return is a measured physical run, not a decorative rotation.

## Workflow

1. **Audit the wizard.** Locate its draft type, launcher, build callback, `PeninsulaRun`, `wallPlacementAt`, countertop surfaces, pony-wall builder, and selected-line cabinet pool.
2. **Capture explicit choices.** Capture the attachment wall, optional locked 45-degree direction, exact ordered cabinet lists per leg, countertop treatment, and optional appliance/pony wall. Attach automatically at the selected wall centre; never ask for a run length or auto-fit/repeat a cabinet.
3. **Validate before building.** Sum selected catalog cabinet widths for each leg; reserve only the required 45-degree joint envelope. Calculate the safe free span after depth-specific corner holds. If the plan does not fit, keep the dialog open. If a remainder is 1/8–6 in., use only a real active catalog filler; otherwise show the remainder.
4. **Build from records.** Place the selected catalog records directly. Preserve cabinet ID, dimensions, master code, price identity, wall ID, and wall offset.
5. **Build surface/support.** Use shared `countertopSurfaces` and pony-wall generation. Stop each countertop at its final cabinet and reject any slab that crosses the room boundary. A split-level selection creates a separate 42-in. raised bar with a 15-in. projection and continuous support behind every connected return.
6. **Make the outcome visible.** Display a live total at the top of the dialog and per-leg selected totals; both must update when a cabinet is added or removed. Show optional planning-only stools on the seating side, opposite cabinet faces; do not price or list those stools as materials.

## Tests and proof

- Test selected-record plans, dynamic total updates after add/remove, catalog-backed remainders, rejection of large remainders, room-bound countertop validation, split-level metadata, and unpriced planning stools.
- Run focused Wizard, countertop, and shared-engine parity tests; then TypeScript and production build.
- Seed a disposable draft. Through real clicks choose cabinets on both legs, build, and capture dialog, Floor Plan, 3D, and Materials & Parts.
- Verify placed codes equal selected options, filler is an actual line item, and supports span all raised-bar legs.
- For production behavior, checkpoint, wait for the published bundle, repeat proof live, and append the evidence ledger.
