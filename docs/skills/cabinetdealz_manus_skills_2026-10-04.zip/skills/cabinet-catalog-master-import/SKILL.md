---
name: cabinet-catalog-master-import
description: Reversibly plan, validate, apply, and prove a Cabinet Dealz master spreadsheet catalog import without changing prices. Use when importing or reconciling a future master cabinet catalog workbook, normalizing master SKU/code changes, preserving legacy aliases/equivalences, activating or retiring catalog rows, or preparing rollback evidence; do not use for designer geometry or pricing changes.
---

# Cabinet Catalog Master Import

Use this workflow to make a **future catalog-only import** safe, reversible, and auditable. Treat the supplied workbook and approved scope as the source of truth; do not reuse historical row counts, sheet names, or mappings as current facts. Do not read or import wholesale/pricing attachments unless separately authorized for a different task.

## Non-negotiable scope gate

1. Obtain written approval of the input workbook, target environment, allowed catalog fields, expected counts, and operator.
2. Default to **NO PRICING CHANGES**. Never insert, update, delete, or migrate `distributor_skus`, `pricing_settings`, `door_styles`, or tier/markup data. Never change `showInDesigner` or designer eligibility from a catalog workbook without separately explicit authorization.
3. Preserve cabinet primary keys. Do not delete catalog rows solely because they are retired or merged; mark an approved row inactive and retain the legacy code mapping.
4. Stop and escalate if the workbook requests a protected-field change, a price file/tab is involved, a mapping is ambiguous, an existing canonical code conflicts, or expected counts are absent. Do not infer approval from prior imports.

> Read protected pricing data only for pre/post integrity checks. A matching checksum proves preservation; it does not authorize price edits.

## 1. Inspect and freeze the input

1. Work on a copy or immutable identifier of the approved master workbook. Record filename, content hash, sheets, headers, source timestamp, target database, and importer version in the run manifest.
2. Identify the primary catalog rows and any alias, merge, or equivalence maps. Normalize comparison keys consistently (case, whitespace, punctuation/dashes, and explicitly approved leading-zero behavior) while retaining each original code verbatim.
3. Validate required columns and types before database access. Reject blank canonical codes, duplicate normalized master codes, duplicate active aliases, aliases that collide with an unrelated master, dangling merge targets, and many-to-one mappings without an approved rule.
4. Classify every row as unchanged, catalog-field update, canonical-code rename, deactivate, reactivate, alias, or equivalence. Build a machine-readable dry-run plan; do not write during planning.
5. Derive and record exact expected counts from the approved plan: source rows, matched/unmatched/ambiguous rows, rows changed, description changes, code renames, aliases added, equivalences added, deactivations, reactivations, snapshots, and change-log records. Require zero unexpected items.

## 2. Resolve canonical masters and legacy codes

1. Match an input master to one cabinet deterministically: exact canonical code first, then approved normalized-code matching, then a documented exceptional mapping. Never take the first of multiple candidates.
2. Maintain a one-to-one claimed-cabinet set for the run. Fail on duplicate claims or unmatched active masters unless explicitly approved in the plan.
3. For a canonical-code rename, retain the former code as an alias of the same cabinet when it does not conflict. Treat dashed legacy codes, including inactive dashed **WER** codes, as compatibility identifiers: keep their text, inactive status where applicable, and resolution path; never silently discard or reactivate them.
4. If a legacy/alias code is also its own cabinet row, preserve that row and create a two-way, active code equivalence to the approved canonical master rather than an alias that masks the row. For an approved merge, create the same equivalence to the merge target.
5. Verify master SKU consistency before applying: each canonical master must resolve uniquely; its `sku`, vendor SKU, and alternate SKU fields must remain internally consistent with the approved workbook and related aliases/equivalences must resolve to that same intended master. Flag conflicting SKU identities for owner review rather than choosing one.

## 3. Generate an approval-grade dry run

1. Query only the current catalog, alias, equivalence, and necessary read-only pricing checksum inputs. Produce per-row old/new values and the exact field-level diff.
2. Exclude protected fields in code with an allowlist of authorized catalog fields; do not rely only on spreadsheet column filtering. Validate the generated SQL/ORM mutation set contains no protected tables or fields.
3. Produce a review report containing:
   - workbook identity and normalization rules;
   - exact count reconciliation and every unmatched, ambiguous, skipped, collision, or exception;
   - every description change and rename (`from` → `to`);
   - all inactive/deactivated rows, specifically any dashed WER codes;
   - aliases and equivalences with canonical targets;
   - pre-apply price checksum and the query definition;
   - planned snapshots and audit-log counts.
4. Obtain approval for this report. If approval changes the plan, regenerate all counts and obtain approval again.

## 4. Apply atomically and reversibly

1. Re-read and validate the live rows immediately before mutation; abort if they no longer match the approved baseline.
2. Start one database transaction. Before changing each cabinet, insert a complete recovery snapshot with a unique run reason and enough metadata to identify the workbook and operator.
3. Apply only approved catalog-column updates. Populate `originalDescription` only under an explicit preservation rule (for example, only when empty); log all changes to description, master code, status, and every changed allowed field with old and new values.
4. Insert aliases and equivalences idempotently after their target validation. Preserve canonical codes, legacy aliases, and inactive records; do not delete price-bearing or historical cabinet rows.
5. Commit only after all planned writes succeed. On any error, roll back the whole transaction, report the failed invariant, and retain the dry-run artifact. Do not attempt partial manual repairs inside the failed run.

## 5. Prove the result before release

1. Recompute the protected price checksum using the exact pre-run query and require byte-for-byte or value-for-value equality. Include row count and stable aggregate/fingerprint values sufficient to detect price, cost, or identity drift. Investigate any mismatch before continuing.
2. Reconcile actual versus approved exact counts for rows, descriptions, renames, status transitions, aliases, equivalences, snapshots, and audit logs. Fail release on any discrepancy.
3. Run live search proof for a representative and risk-focused sample: each renamed code, dashed WER legacy code, active alias, merged/inactive source code, and canonical master must find or resolve as expected.
4. Run alias-resolution proof end-to-end: resolve every newly created alias/equivalence (or a documented exhaustive query), verify its canonical cabinet ID and master SKU, and verify a legacy design/code path resolves to the intended priced master without changing price data.
5. Archive the run manifest, dry-run plan, pre/post checksums, SQL/query definitions, count reconciliation, snapshot run reason, audit-log identifiers, search evidence, and rollback instructions in the approved operational location.

## Rollback protocol

1. Use the run-specific recovery snapshots and audit log to construct a dry-run reverse plan; never use an older run's counts or snapshots.
2. Verify the reverse plan affects only rows and alias/equivalence records from this run and still excludes all protected pricing/designer fields.
3. Execute rollback in one transaction, restore captured catalog values and prior code relationships, then repeat price checksum, count reconciliation, live search, and alias-resolution proof.
4. Record the rollback outcome and leave the original import artifacts intact for audit.

## Completion gate

Declare the import complete only when the owner-approved plan, atomic commit, protected-field inspection, unchanged pre/post price checksum, exact count reconciliation, snapshots, audit logs, and live search/alias-resolution evidence all pass. Otherwise report the import as blocked or rolled back, not complete.
