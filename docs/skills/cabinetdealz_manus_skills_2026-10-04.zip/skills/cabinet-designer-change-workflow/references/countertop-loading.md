# Countertop update indicator: implementation and proof

Read this only when adding or modifying a busy state for expensive Designer plan/3D geometry.

## What actually worked

- Keep cabinet selection, dragging, panels, and the tool rail responsive. Stage **only** the geometry inputs (room, placed cabinets, islands, sinks, pony walls as applicable) as one `useMemo` snapshot and pass that object through React's `useDeferredValue`. Use the deferred snapshot consistently for a countertop pass; mixing new cabinets with old room coordinates creates apparent jumps.
- Show a lightweight, `pointer-events-none` badge while the current geometry snapshot differs from the deferred one. For 3D, keep it visible until the renderer signals that the new scene's **first frame has painted**. Maintain the callback in a ref so a parent's status-only rerender does not rebuild WebGL geometry.
- In the Floor Plan component, memoize costly polygon generation by the *snapshot's room/cabinet/island references*, not by selection state. Do not use `deferredIsland ?? island` if the deliberately deferred value is `null`: that mistakenly substitutes the current island. Instead distinguish “no snapshot” from “snapshot whose island is null.”
- Place the badge clear of view controls, use `role="status"`, `aria-live="polite"`, and respect `prefers-reduced-motion`. Use `motion-reduce:animate-none` (or equivalent) on its spinner. Don't cover click targets or open a blocking modal.
- Cancel outstanding animation frames in effect cleanup. On WebGL-unavailable fallback, clear the status instead of leaving a permanent spinner. If the scene can be replaced during computation, associate completion with the actual snapshot, not a generic boolean.

## Prove the timing

1. Load an isolated test draft, verify the owner-scoped storage key actually matches the test identity, and wait for cabinets to appear. Draft load can normalize/split fillers: confirm restored cabinet IDs and positions.
2. Change geometry **as a user would**: select and nudge a base in Floor Plan, or edit a room dimension. Merely switching from 3D to 3D or selecting an unrelated control does not test recomputation.
3. Observe a `MutationObserver` on the status element and record `(performance.now(), visible)` transitions. Require `false → true → false` during the update, with a rendered scene afterward and no uncaught page errors. In a complex saved room, also capture a screenshot during the pending state; a fast room may show the badge for only a frame or two.
4. Re-run typecheck, focused tests, production build, and browser interaction. Compare full-suite failures against an unchanged baseline; unrelated network/LLM failures must be reported separately.

## Limits

A badge does **not** make a long, synchronous JavaScript calculation nonblocking. If the main thread remains blocked before the browser can paint, split/schedule the calculation or move a suitable pure computation to a worker. Measure responsiveness and avoid claiming improvement from a spinner alone. Do not change countertop math, pricing, or cabinet placement to add a progress indicator.
