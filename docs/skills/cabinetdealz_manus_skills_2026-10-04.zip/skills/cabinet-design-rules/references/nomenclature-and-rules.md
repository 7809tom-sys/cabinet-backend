# Cabinet Nomenclature & Extended Placement Rules

## Cabinet Type Codes

| Code | Full Name | Category | Depth |
|------|-----------|----------|-------|
| B-* | Base cabinet | Base | 24" |
| W-* | Wall cabinet | Wall | 12" |
| BBC-* | Blind Base Corner | Base | 24" |
| BWC-* | Blind Wall Corner | Wall | 12" |
| LS-* | Lazy Susan (base corner) | Base | 36" (square) |
| DC-* | Diagonal Corner (base) | Base | square |
| WDC-* | Wall Diagonal Corner | Wall | square |
| SB-* | Sink Base | Base | 24" |
| DB-* | Drawer Base | Base | 24" |
| BWB-18 | Base Waste Basket (trashcan pull-out) | Base | 24" |
| BES-* | Base End Shelf | Base | 24" |
| WEC-* | Wall End Cabinet (open end) | Wall | 12" |
| RW-* | Refrigerator Wall | Wall | 24" |
| WF-* | Wall Filler | Filler | — |
| BF-* | Base Filler | Filler | — |
| TF-* | Tall Filler | Filler | — |
| VA-* | Valance (arched, above windows) | Trim | — |
| MW-* | Microwave cabinet | Wall | 12" |
| GS-* | Glass Stacker | Wall | 12" |
| HB / TFHB | Tall Full Height Base | Tall | 24" |

## Placement Suggestions (Auto-Suggest Logic)

After placing certain cabinets, the tool auto-suggests complementary pieces:

| Trigger | Suggestion |
|---------|-----------|
| Base cabinet placed | Wall cabinet above (same width, user-selected height 42/36/30") |
| BBC placed | 3" filler on blind side |
| Microwave (MW-*) placed | Bridge cabinet above |
| WDC placed | 12" wall cabinets on both adjacent walls |
| Base diagonal (DC/LS) placed | 12" base cabinets on both adjacent walls |
| Sink base (SB) placed | Suggest Pelican sinks that fit |
| Wall cabinet near window | Suggest WEC (6" or 9") next to window |
| 30" wall cabinet placed | Suggest wine rack combo (wine rack + bridge + stem glass holder) |

## Key Geometry Functions (design.ts)

| Function | Purpose |
|----------|---------|
| `isBlindCorner(code)` | Returns true for BBC-*, BWC-* prefixes |
| `isLCornerCabinet(code)` | Returns true for LS, DC, WDC — NOT blind corners |
| `footprintDepth(cabinet)` | Returns depth: 24" for base, 12" for wall, square for L-corners |
| `blindPullRange(cabinet)` | Returns `{ min: 3, max: 6 }` for blind portion |
| `resolveSwing(placed)` | Determines door hinge side from stored swing property |
| `bearsCountertop(code)` | True if cabinet gets a countertop (base, sink base, etc.) |
| `isRangeOrOven(code)` | True for range/oven appliances (affects backsplash height) |
| `wallCabinetTopLine(height)` | Returns top of wall cabinet line for given wall cab height |

## Rendering Layers (Elevation View, back to front)

1. Wall background
2. Backsplash (full wall width, 18" default)
3. Countertop (spans base cabinet run)
4. Cabinet boxes (toe kick, face frame, door panels)
5. Door texture (door sample image clipped to individual panels)
6. Hardware overlay (handles on opposite side from hinge)
7. Trim (crown molding, light rail — match cabinet color)
8. Dimension lines and labels

## Plan View Rendering (Bird's Eye)

- Base cabinets: filled rectangles with door indicator (hinge bar)
- L-corner (LS/DC): square with diagonal clip path
- Blind corner (BBC): simple rectangle, NO diagonal clip
- Wall cabinets: lighter/outlined rectangles (toggleable visibility)
- Annotations: draggable text labels
- Dimension lines: auto-generated showing all cabinet widths
