---
name: cabinet-design-rules
description: Cabinet kitchen design tool placement rules and rendering logic for the CabinetDealz 2D designer. Use when fixing, adding, or modifying cabinet placement behavior, elevation rendering, plan-view footprints, backsplash/countertop rendering, or any design-tool geometry logic.
---

# Cabinet Design Rules

Authoritative placement, rendering, and interaction rules for the CabinetDealz 2D kitchen designer. Apply these rules when modifying code in:

- `client/src/pages/DesignTool.tsx` (placement logic, suggestions, interactions)
- `client/src/components/design/ElevationView.tsx` (front/elevation rendering)
- `client/src/components/design/PlanCanvas.tsx` (bird's-eye plan view)
- `client/src/lib/design.ts` (shared geometry helpers, constants, validators)

## Standard Dimensions (STD constants in design.ts)

| Constant | Value | Notes |
|----------|-------|-------|
| BASE_DEPTH | 24" | All base cabinets including blind corners |
| WALL_DEPTH | 12" | Standard wall cabinets |
| FRIDGE_DEPTH | 24" | Refrigerator cabinets |
| TOE_KICK | 4.5" | Height of toe kick from floor |
| COUNTERTOP_H | 1.5" | Countertop thickness |
| COUNTERTOP_TOP | 37.5" | Top of countertop (toe kick + 31.5" + 1.5") |
| BACKSPLASH_H | 18" | Standard backsplash height |
| WALL_CAB_BOTTOM | 54" | Bottom of standard wall cabinets |

## Blind Corner Cabinets (BBC)

BBC is a **rectangular** cabinet, NOT an L-shaped corner cabinet.

### Footprint
- BBC-36 = 36" wide × 24" deep (standard base depth)
- BBC-42 = 42" wide × 24" deep
- BBC-48 = 48" wide × 24" deep
- NEVER square (not 36×36, not 42×42)
- `isLCornerCabinet()` must EXCLUDE blind corners — only lazy Susan (LS) and diagonal corners (DC) are true L-corners

### Pull Range (Blind Portion)
- The "pull" is the blind portion hidden behind the perpendicular wall
- Minimum pull: 3"
- Maximum pull: 6"
- Auto-stop: place at 6" pull (the max) from the corner wall
- `blindPullRange()` returns `{ min: 3, max: 6 }` — NOT width+3 / width+6

### Door Orientation
- Door ALWAYS faces the exposed/open side (away from the corner wall)
- Left corner → door on right (`swing: "right"`)
- Right corner → door on left (`swing: "left"`)
- Determine corner side: if `posAlong <= 2` (near wall start), corner is on left
- Auto-set swing on placement in `addCabinet`

### Filler Requirement
- All blind corners require a 3" filler on the blind side (between BBC and adjacent cabinet)

## Backsplash Rendering (ElevationView)

### Coverage
- Spans the **full wall width** from corner to corner (position 0 to wallLen)
- NOT just behind cabinets — covers all exposed wall in the backsplash zone

### Height Rules
- Default: 18" tall (from countertop top at 37.5" to 55.5")
- Behind a range (no upper cabinet above): stretch to wall cabinet top line or 84" (whichever is lower)
- Behind wall cabinets: backsplash fills from countertop to bottom of wall cabinet
- The 18" rule applies to open wall areas with no wall cabinet above

### Rendering Order
1. Compute base backsplash rect: full wall width × 18" starting at countertop top
2. For each range/oven position with no wall cabinet above: extend that segment up
3. Clip/merge segments as needed

## Wall Cabinet Placement

- Bottom at 54" (standard)
- If height < 30": move bottom UP so top aligns with standard top line
- 3" minimum clearance from windows and doors
- Floor-to-ceiling (tall) cabinets: bottom at toe kick (4.5")
- Glass stackers: auto-stack on top of wall cabinets

## Base Cabinet Placement

- Always start at ground level (bottom = 0)
- Lock feature prevents accidental movement after placement
- After placing a base cabinet, suggest matching wall cabinet above (same width)

## Corner Cabinets (True L-Corners: LS, DC)

- Lazy Susan (LS-36): 36" × 36" square footprint with diagonal front
- Diagonal Corner (DC): square footprint with clipped corner
- These ARE L-shaped and get the square treatment in `isLCornerCabinet()`
- Render with diagonal clip path in plan view

## Door/Hinge Rendering

- Handle/knob goes on the OPPOSITE side from the hinge
- `resolveSwing(p)` determines hinge side from `p.swing` property
- In elevation view: DoorFront component renders panel structure with hinge indicator
- For blind corners: `blindOnLeft` prop overrides normal swing logic

## Catalog Filter Behavior

- When user picks a door style: auto-open the catalog panel showing filtered cabinets
- Set `mobilePanel = "catalog"` and `paletteTab` to cabinets tab after style selection
- Ensures immediate access to available cabinets in the chosen style

## Fix Workflow

When fixing design tool bugs:

1. Identify which file owns the logic (placement → DesignTool.tsx, rendering → ElevationView/PlanCanvas, geometry → design.ts)
2. Check `isBlindCorner()`, `isLCornerCabinet()`, `footprintDepth()`, `blindPullRange()` for cabinet type classification issues
3. Run `npx tsc --noEmit` after every change
4. Verify in screenshot before checkpointing
5. Never publish until user confirms the fix works
