---
name: cabinetdealz-catalog-spreadsheet-import
description: Safely audit, stage, import, and validate CabinetDealz distributor catalog spreadsheets, including SKU, nomenclature, price, dimensions, shipping, and door-style data. Use when a vendor uploads a catalog or price spreadsheet.
---

# CabinetDealz Catalog Spreadsheet Import

Treat a vendor spreadsheet as staged input requiring reconciliation and audit—not authority to overwrite master data silently.

## Guardrails

- Preserve catalog rows, prices, master codes, aliases, and 3D shapes unless a precise change is approved.
- Require source distributor/line and door-style scope; never apply a vendor file to every distributor by default.
- Use master nomenclature and two-way equivalence groups; do not hand-translate codes in the UI.
- Keep prices sourced from distributor price lists. A reference catalog supplies dimensions/descriptions only to its own line.
- Do not delete unmatched rows; stage them with a clear reason.

## Import workflow

1. Profile sheets, header/delimiter/encoding, mapped columns, row count, duplicates, blanks, currency, and units. Preserve the original file outside web source.
2. Normalize whitespace/case and typed dimensions while keeping raw values and source row numbers.
3. Map exact master code, existing equivalence group, and distributor SKU. Do not infer an alias from a superficial string match.
4. Classify each row: exact/alias match, new code, dimension/description conflict, required-field missing, duplicate source, or price change.
5. Report counts and sample conflicts before live writes. Obtain explicit mutation approval.
6. Apply transactionally to the chosen distributor/style scope, logging source file and row. Leave unmatched data intact.
7. Validate selected-line queries, Designer availability, material list/pricing identity, and importer admin views across base, wall, tall, corner, filler, and accessory families.

## Deliverables

Save normalized staging, mapping report, conflict report, applied-row log, validation queries, and before/after counts. State every unapplied row and why.
