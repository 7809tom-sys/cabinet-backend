---
name: cabinet-side-by-side-comparison
description: Compare the regular Designer and Continuous Wall Builder using identical U-shape layouts with an angled peninsula, producing honest Floor Plan and 3D evidence. Use when validating rendering parity, countertop continuity, cabinet joints, or a reported Designer-versus-Wall-Builder mismatch; do not use this skill to change placement or rendering rules.
---

# Cabinet side-by-side comparison

## Purpose

Produce an apples-to-apples comparison of the **regular Designer** and **Continuous Wall Builder** for the same U-shape plus angled peninsula. Treat the Wall Builder as a reference to measure, not as something to alter for a prettier screenshot. Defer cabinet placement, countertop geometry, and 3D rendering semantics to the existing project rules and implementation; this skill defines only the comparison and evidence protocol.

## Workflow

1. **Record the test identity.** Give the run an origin/build label for each tool (for example, local commit/build versus live URL and timestamp). State explicitly whether each image came from local development, a deployed preview, or the public site. Never call a local result “live.” Record viewport size, browser, camera orientation, wall visibility, and material/theme.
2. **Define one canonical layout.** Specify the room outline, U-shaped runs, cabinet IDs/types, widths and depths, angled peninsula cabinet, rotations/angles, fillers, countertop thickness/overhang, backsplash, and materials. Keep this specification unchanged between tools. Do not hand-tune positions in one tool to compensate for a difference in the other.
3. **Create or restore, then audit.** Build the layout independently in each tool using the same canonical specification. Reload each browser state before capture and count every cabinet, angled cabinet, filler, countertop section, and other relevant object. Compare the restored counts with the specification; stop and label the result invalid if counts differ. Preserve the Wall Builder’s behavior even when the Designer differs.
4. **Normalize the capture.** Use the same browser viewport and zoom. Capture a Floor Plan screenshot with the same pan/zoom, grid/room-wall visibility, labels, and material visibility. Capture a 3D screenshot after using the same camera orientation, distance, lighting/material mode, and room-wall visibility. If a camera cannot be matched exactly, document the difference rather than editing geometry to hide it.
5. **Assert geometry before judging pixels.** Inspect source/state or app diagnostics when available and record assertions for: identical cabinet centers, dimensions, rotations, and IDs; the angled cabinet’s intended adjacency to both neighbors; shared miter/turn vertices; countertop polygons covering only supported cabinets; no unintended floating slab; no gap at the angled joint; flush cabinet fronts/tops; and consistent run/room origin. Use tolerances appropriate to the app’s units and state them. A screenshot alone cannot prove a geometry assertion.
6. **Compare in pairs.** Put each tool’s Floor Plan images side by side, then each tool’s 3D images side by side, with origin/build labels on or immediately beside every image. Check both overall U-shape and a close view of the angled peninsula. Keep original captures; do not crop away a defect. If a render script is available (such as `/tmp/render_pair.py`), inspect its assumptions and use it only as a capture aid after verifying URL, injection, viewport, and selectors.
7. **Report differences honestly.** Separate geometry/state mismatches from camera, visibility, loading, anti-aliasing, and material differences. Report local-vs-live status, browser-restored counts, exact assertions, screenshot paths/URLs, and any unverified claim. If the Designer fails, record the failure; never modify the Wall Builder or distort the canonical layout merely to make screenshots match.

## Pass/fail checklist

Mark each item **PASS**, **FAIL**, or **UNVERIFIED**, with evidence:

- [ ] Same canonical U-shape plus angled peninsula, cabinet IDs/types, dimensions, rotations, fillers, materials, and countertop settings.
- [ ] Browser reload restores identical object counts and intended room/layout state in both tools.
- [ ] Same viewport, zoom, camera, lighting/material mode, and wall/visibility settings are documented and used.
- [ ] Floor Plan pair shows matching run origins, cabinet footprints, angled turn, countertop outline, and supported coverage.
- [ ] 3D pair shows matching cabinet heights/fronts/tops and a continuous countertop through the angled turn.
- [ ] No gap at either side of the angled cabinet; cabinet bodies are flush to intended neighbors.
- [ ] No floating or unsupported countertop slab, including an end piece without a cabinet beneath it.
- [ ] Countertop joints are flush/mitered as intended: no seam, step, overlap, or unexplained triangle.
- [ ] Geometry assertions agree with screenshots, or discrepancies are explicitly explained.
- [ ] Every capture has an origin/build label and local-versus-live status; unresolved items remain UNVERIFIED.

## Evidence record

Return a compact record containing canonical-layout identifier, tool/build/origin, URL or local route, timestamp, browser and viewport, restored counts, camera/visibility/material settings, geometry assertions with tolerances, screenshot paths, checklist results, and known limitations. Include a close-up when a 45-degree joint is under review. Do not claim deployment, live parity, or saved state without direct evidence.
