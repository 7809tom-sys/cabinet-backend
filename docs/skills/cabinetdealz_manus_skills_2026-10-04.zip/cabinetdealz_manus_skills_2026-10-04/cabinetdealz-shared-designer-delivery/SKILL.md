---
name: cabinetdealz-shared-designer-delivery
description: Deliver CabinetDealz 3D Designer and Continuous Wall Builder features or bug fixes through one shared engine, with catalog-safe implementation, local browser proof, checkpointing, published-site verification, screenshots, and ledger evidence. Use for CabinetDealz cabinet placement, walls, countertops, fillers, 2D/3D parity, materials-list, and Designer configuration work.
---

# CabinetDealz Shared Designer Delivery

Use this workflow for a change that affects the CabinetDealz Designer, including Continuous Wall Builder. Treat the standard-room Designer as the reference behavior unless the owner explicitly says otherwise.

## Non-negotiable constraints

- Read `/home/ubuntu/skills/cabinet-design-rules/SKILL.md` and `/home/ubuntu/skills/webdev-readme-fullstack/SKILL.md` before changing code.
- Inspect `git status --short`, current checkpoints, and `todo-alvsvcze.md` before editing.
- Keep **one engine**: normal Designer and Continuous Wall Builder must reuse shared geometry, placement, pricing, and renderer code. Do not add `if wallBuilder` behavior forks.
- Do not invent catalog rows, prices, codes, SKU mappings, or cabinet shapes. Do not change them to hide a defect unless the owner expressly asks.
- Do not call a change complete until it has been proven on `https://www.cabinetdealz.com`.
- Never use the `file` CLI on screenshots. Use the image-reading tool.
- Preserve the user’s saved design. Test it only from an isolated copy/draft unless the owner approves saving changes.

## Delivery workflow

### 1. Establish exact acceptance criteria

Convert the request into a compact checklist that says what must change and what must not change. Include every requested view and tool, e.g. Floor Plan, 3D, standard room, Continuous Wall, materials list, cart, saved design.

For a diagnosis-first request, stop after the diagnosis report and send the requested file/table/function/data findings before changing behavior.

### 2. Trace the source of truth

Before editing, identify all involved paths:

| Concern | Typical source |
|---|---|
| Shared placement, collision, run geometry, countertops | `client/src/lib/design.ts` |
| 45°/polygon wall geometry | `client/src/lib/polygonRoom.ts` |
| 2D rendering and drafting labels | `client/src/components/design/PlanCanvas.tsx` |
| 3D rendering | `client/src/components/design/InteractiveRoom3D.tsx` |
| Designer state, save/restore, dialogs, materials/cart | `client/src/pages/DesignTool.tsx` |
| Catalog, price and alias data | `server/routers/design.ts`, `server/db.ts`, `drizzle/schema.ts` |

For a discrepancy between tools, document the base path and the upper/wall/tall path separately. Prefer one common helper with explicit physical inputs (wall id, offset, width, depth, height range) over post-placement patches.

For catalog or pricing questions, query existing data read-only first. Report exact row evidence, names, IDs, and mapping direction before any data mutation.

### 3. Implement at the shared layer

1. Put physical rules in `design.ts` or the appropriate shared module.
2. Thread shared state through the saved `RoomData` / `PlacedCabinet` model, restore normalization, Floor Plan, 3D renderer, materials/cart and takeoffs as applicable.
3. Keep visual layers tied to the same geometry source. For countertops, prefer `countertopSurfaces` and shared run polygons rather than per-cabinet rectangles.
4. Make additions opt-in when the request is a selectable treatment. Existing saved designs must retain their prior appearance unless a deliberate compatibility rule is approved.
5. Make no `$0.00` fallback or silent materials-list drop. Missing-price state must remain visible and block cart/checkout when that policy applies.

### 4. Add focused regression tests

Add a small test file near the shared module for the physical rule. Cover the requested variants—not just a screenshot condition.

Examples:
- 45° and 90° joints, standard room and Continuous Wall room.
- Actual cabinet depth per layer, not a hard-coded 24-inch base depth.
- Lower worktop and raised bar as separate surfaces, heights, overhangs, and return geometry.
- Saved-design repair only when the item is within snap tolerance; preserve all unrelated positions.

Run:

```bash
cd /home/ubuntu/cabinet-dealz
pnpm run check
npx vitest run <focused-test-files>
pnpm run build
git diff --check
```

If a broad pre-existing test failure remains, prove it also fails at `HEAD` or record why it is intentionally incompatible with a published rule. Do not describe it as introduced by the new change.

### 5. Produce local browser proof

Use Playwright and actual Designer interactions whenever feasible.

- Seed only an isolated local-storage draft using the owner email’s `cabinet-dealz:designer-draft:v2:owner:<email>` key and matching active-draft key.
- Use a real catalog click or saved draft data that survives normal restore logic; do not merely inject renderer-only state.
- Capture relevant 2D, 3D, dialog/materials/cart views and a JSON result containing measured assertions and browser errors.
- For saved-design verification, clone the design payload to the draft; do not update the database record.
- Inspect every image and JSON result before continuing.

Store proof under `docs/proofs/<feature>-local-{plan,3d,materials}.png` plus JSON.

### 6. Checkpoint, deploy, and verify live

1. Save a production checkpoint with `webdev_save_checkpoint` after local validation.
2. Detect the deployed Designer chunk rather than assuming the root HTML proves deployment:

```bash
python /home/ubuntu/skills/cabinetdealz-shared-designer-delivery/scripts/wait_live_designer_bundle.py \
  --base https://www.cabinetdealz.com \
  --contains '<a stable UI/test-id/source marker from the changed feature>' \
  --output /tmp/<feature>-deploy.json
```

3. Rerun the same proof with `BASE=https://www.cabinetdealz.com` and a cache-busting query.
4. Save live PNG/JSON proof under `docs/proofs/`. Record the deployed `index`, `DesignTool`, and `InteractiveRoom3D` bundle filenames in JSON and the ledger.
5. Append a factual entry to `todo-alvsvcze.md`, then save a docs-only evidence checkpoint.

### 7. Final report

Report only observed results:

- What changed in plain language.
- Whether it was proven in standard / Continuous Wall / 2D / 3D as requested.
- The live bundle filenames and any consciously unresolved catalog or test limitation.
- Screenshots only when the owner requested proof.

Use **“live verified”** only after the published browser proof succeeds. Do not say “fixed” before that point.

## Quick decision table

| Situation | Required action |
|---|---|
| Owner requests diagnosis first | Read/query/report first; do not change code yet. |
| Same cabinet behaves differently in Wall Builder | Find and remove the fork; fix shared code. |
| Feature needs a catalog item not present | Report unavailability and closest real item; do not substitute silently. |
| Missing price | Keep the item visible, flag it, preserve the line, block checkout if policy requires. |
| Saved design needs repair | Only normalize items in snap tolerance; preserve all other coordinates. |
| Live deployment unclear | Trace index → dynamic Designer chunks and verify a stable marker in the chunk. |

## Reusable deployment detector

Use `scripts/wait_live_designer_bundle.py` when live proof depends on a newly published Designer source marker. It writes the observed index/Designer/3D bundle names and exits nonzero on timeout.
