---
name: cabinet-peninsula-wizard
description: Regular Cabinet Dealz Designer Peninsula Wizard workflow and diagnostics. Use when creating, testing, or troubleshooting a Wizard-built peninsula, including its optional 45-degree return, cabinet-facing side, appliance opening, pony wall, countertop, waterfall, or Plan/3D continuity. Do not use for Continuous Wall Builder room geometry, pricing, or catalog/product changes.
---

# Cabinet Peninsula Wizard

Use the **regular Designer Peninsula Wizard** to create a cabinet-ready peninsula from a cardinal room wall. Keep its model separate from Continuous Wall Builder: the Wizard writes `room.peninsulaRuns`; Continuous Wall Builder writes measured room `vertices` and `customWalls`.

## Scope and source of truth

- Start in `client/src/pages/DesignTool.tsx`: inspect `openPeninsulaWizard`, `buildPeninsulaWizardLayout`, the Wizard dialog, and the peninsula settings save path before changing behavior.
- Use `client/src/lib/design.ts` for run geometry, collision-free seating, support detection, countertop surfaces, pony-wall construction, and restoration normalization.
- Use `PlanCanvas.tsx` and `InteractiveRoom3D.tsx` only to verify that the same computed model renders correctly; do not invent view-specific geometry.
- Preserve the selected cabinet line/style. The Wizard requires an available compatible cabinet pool and intentionally adds only its placement records; do not change prices, SKUs, catalog data, or product configuration.

## Build the regular Wizard peninsula

1. **Open and prepare.** Work in the regular Designer, select a cabinet line and door style, then open **Peninsula Wizard**. Confirm the room has an unobstructed path from the selected cardinal start wall. A locked layout prevents creation.
2. **Set the attachment.** Choose the start wall and measured offset from its corner. The primary leg must leave that wall straight through the room interior; it is not a diagonal primary leg. Request a primary length, then let the run-length guard cap it to measured room clearance. A primary run needs the Wizard minimum usable length.
3. **Choose the optional end.** Select no end, or exactly one connected 45° left/right end and its length. Treat the end as a child run (`parentRunId`), not a replacement for the primary run. Check its available room clearance before accepting it; the shared geometry reserves the true-45 inside-corner hold (`PENINSULA_INSIDE_CORNER_CLEARANCE_IN`) rather than seating a base directly at that acute joint.
4. **Choose the cabinet face.** Set left or right based on the side whose cabinet backs meet the run. Verify this before placement: it controls seating direction, front overhang direction, waterfall orientation, dimensions, and 3D facing. Existing cabinets retain their persisted side when a run setting changes.
5. **Choose an appliance deliberately.** The Wizard offers no appliance, a 24-inch dishwasher (`DW-24`), or a 24-inch wine cooler. It seats the appliance on the primary run only, rejects it when no collision-free primary-run space exists, then fills remaining safe spans. Treat an appliance opening as an opening within a supported countertop run, not countertop support by itself.
6. **Choose the initial worktop treatment.** Keep the standard finished front edge unless actual seating is requested; choose 12 or 15 inches for seating. Optionally request the waterfall, which belongs only at the exposed terminal end of the connected assembly.
7. **Choose the endpoint pony wall if needed.** The Wizard's pony-wall option creates a measured wall snapped to the final endpoint—on the 45° child when present, otherwise on the primary. Confirm its width, height, and room fit. Never substitute a loose rectangle for this attached wall.
8. **Build and inspect.** The Wizard creates the runs, seats the chosen appliance, and fills each safe segment with compatible base cabinets. It uses a catalog filler only when the selected line contains an appropriate cuttable filler; it must not persist a generic placeholder.
9. **Lock when approved.** Use the peninsula settings lock to freeze the attachment and connected returns before unrelated work. Unlock deliberately before changing split point, turn, direction, length, adding a return, or deleting a connected run.

## Add the drywall-supported 15-inch raised bar after build

Use the selected peninsula's settings dialog—not the creation Wizard—for a full back pony wall and split-level bar.

1. Enable **Drywall pony wall behind cabinet run** to create a finished wall behind every run in the connected assembly. Configure paint/texture only as a layout appearance; keep it attached to the runs and verify it remains inside the measured room.
2. Enable **Split-level raised seating bar**. This makes a separate 42-inch finished-height bar behind the cabinet backs, enables the supporting drywall pony wall, and keeps the lower worktop's ordinary seating setting at zero.
3. Select the **15-inch seating projection** for the raised bar. Do not model this as a deeper lower worktop. The settings apply across the connected root and its 45° child so the turn has no uncovered notch.
4. Use **Bar top over drywall pony wall** only for a single-level top that crosses the drywall wall; it is distinct from the raised-bar option.

## Verify surfaces and rendering

Treat `countertopSurfaces(placed, room)` as the common Plan/3D source of truth.

- Require real countertop support: a regular base, eligible corner/base support, or a confirmed installed filler group. Loose fillers, panels/skins, tall cabinets, and appliances do not create standalone tops. An empty peninsula should not receive an invented slab.
- Expect a dishwasher to remain beneath a continuous supported top; do not cut the run merely because the appliance is present.
- For a connected 45° assembly, retain each run's support and let the peninsula miter/unification and void-fill helpers produce the shared polygon. Do not add an independent rectangular slab, a decorative bridge over a free gap, or Plan-only geometry.
- Confirm in Floor Plan that the shared surface covers all supported cabinet corners and contains one clean 45° seam/closure. Confirm in 3D that `addThreeDPeninsulaCountertops` extrudes those same polygon surfaces at the correct coordinates and height.
- Confirm a waterfall appears once, at the terminal exposed end only. Confirm the raised bar is a separate 42-inch slab, not a duplicate lower slab.

## Diagnose common failures

| Symptom | Inspect first | Correct direction |
|---|---|---|
| Wizard refuses to build | Cabinet pool, layout lock, primary clear room | Select a cabinet line/style, unlock the layout, shorten/reposition the primary run. |
| 45° child is rejected or cabinets avoid its joint | Parent/child relationship, turn/direction, measured clearance, 45° hold | Keep a straight primary; make the return a `parentRunId` child; shorten the primary or choose no angled end rather than bypassing the clearance. |
| Incomplete 45° countertop seam or triangular void | `countertopSurfaces`, support segments on both legs, miter/unified/void-fill output, Plan polygon then 3D polygon extrusion | Restore run ownership and real base support first. Use the shared peninsula helpers; do not patch PlanCanvas or add a floating 3D slab. Run the 45° continuity and void-fill tests. |
| Top stops at dishwasher | Appliance placement and adjacent base support | Keep the dishwasher as an appliance opening; restore the surrounding supported run. Do not make the appliance counter-bearing. |
| Floating or unsupported top | `bearsCountertop` classification, run membership, installed-filler metadata | Remove unsupported surface logic. Seat the item on the intended peninsula run and use a genuine support or confirmed filler group. |
| Filler/cabinet shifts or disappears after load | Persisted `wallId`, `wallOffset`, `peninsulaSide`, and `normalizeLegacyPeninsulaCabinets` before `setPlaced` | Restore canonical peninsula placement before Plan/3D. Use an actual selected-line catalog filler for remainders; never repair only screen `x`/`y` or add a placeholder filler. |
| Endpoint or back pony wall drifts after editing | `peninsulaRunId`, endpoint ownership, `ponyWallFitsRoom` | Rebuild it with the attached pony-wall helper and validate all corners inside the room; do not preserve a stale loose position. |
| 15-inch raised bar is missing at return or appears as a deep worktop | Root-owned connected treatments, drywall back pony walls, raised-bar surfaces | Enable the raised bar in peninsula settings, select 15 inches, retain its drywall support, and validate the separate raised-bar surfaces across every connected run. |

## Keep the two tools distinct

Use **Peninsula Wizard** for one cardinal-wall primary run, optional connected 45° end, Wizard auto-fill, and `peninsulaRuns` countertop logic. Use **Continuous Wall Builder** only when the user needs a measured wall path/room outline with arbitrary segments; it is driven by `WallBuilder.tsx` and `polygonRoom` geometry. Do not convert a Wizard repair into custom-wall geometry or copy behavior between models without an explicit compatibility task.

## Validate changes

Run focused regressions from `/home/ubuntu/cabinet-dealz` after a related code change:

```bash
pnpm vitest run \
  client/src/pages/DesignTool.peninsulaWizard.test.ts \
  client/src/pages/DesignTool.peninsulaAutoFill.test.ts \
  client/src/pages/DesignTool.peninsulaCountertopContinuity.test.ts \
  client/src/lib/peninsulaVoidFill.test.ts \
  client/src/lib/design.peninsulaPonyWall.test.ts \
  client/src/pages/DesignTool.peninsulaRestore.test.ts \
  client/src/pages/DesignTool.peninsulaAssemblyLock.test.ts
pnpm check
```

Add the narrowest regression that proves the reported behavior. For a 45° rendering defect, test `countertopSurfaces` polygons and `addThreeDPeninsulaCountertops` together; a source-string/UI-only test is insufficient.
