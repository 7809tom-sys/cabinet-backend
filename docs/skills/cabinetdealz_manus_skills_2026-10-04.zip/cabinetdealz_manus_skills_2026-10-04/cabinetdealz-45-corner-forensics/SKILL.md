---
name: cabinetdealz-45-corner-forensics
description: Diagnose and repair CabinetDealz 45-degree and 135-degree cabinet, filler, countertop, wall-seat, or corner-span defects. Use when an angled corner has a gap, overlap, wrong facing, missing filler, or incorrect countertop infill.
---

# CabinetDealz 45-Degree Corner Forensics

Treat a 45-degree corner as measured shared geometry, never as a visual patch.

## Non-negotiable rules

- Read `cabinet-design-rules` before changing geometry.
- Fix the shared engine, renderer, or plan canvas; do not fork Standard Designer and Continuous Wall Builder behavior.
- Preserve catalog codes, prices, and shapes unless a specific catalog change is authorized.
- Do not rely on an image alone: derive wall run, wall ID, offset, rotation, depth, and height range.

## Forensic sequence

1. Copy a saved design or seed an isolated fixture. Record vertices/custom walls, cabinet IDs/codes, x/y, rotation, dimensions, wall IDs/offsets, fillers, countertop surfaces, and selected line.
2. Classify the symptom: wrong wall seat/facing; depth-specific hold/free span; height-overlap collision; miter filler eligibility/price gate; countertop support/infill; or renderer-only face/body transform.
3. Trace `wallPlacementAt`, `freeSegmentsOnWall`, `insideCornerHoldIn`, `customWallCornerReservationCollision`, `countertopSurfaces`, and angled filler repair. Use actual cabinet depth—base, wall, and tall layers do not share a 24-in. assumption.
4. Apply the smallest shared correction. Preserve physical positions while repairing saved designs. Restore required geometry even with a missing price; allow the price flag to handle it.
5. Test 45-degree and 135-degree walls in both standard and Continuous Wall rooms with base/upper placement, fillers, counter surfaces, and material lines.

## Proof standard

- Use real catalog-backed cabinets and fillers.
- Capture Floor Plan, 3D, Materials & Parts, and geometry JSON.
- Verify locally and on the published site before claiming a live fix.
- Record the deployed bundle, checkpoint, and proof paths in the validation ledger.
