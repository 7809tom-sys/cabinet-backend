# Cabinet Dealz Manus skills — 2026-10-04

This ZIP contains **nine reusable skills** from the Designer, Peninsula Wizard, crown, tablet, forensic testing, and catalog-import work in this session. Each skill resides under `skills/<name>/` with its required `SKILL.md` and any supporting references or scripts.

| Skill | One-line purpose |
|---|---|
| `cabinet-design-rules` | Established cabinet dimensions, classification, placement, and plan/elevation rendering rules. |
| `cabinet-designer-change-workflow` | Reproduce, diagnose, test, browser-verify, and checkpoint regular Designer changes; includes countertop loading-indicator guidance. |
| `cabinet-peninsula-wizard` | Build and troubleshoot the regular Designer's peninsula, optional 45° return, supported countertop, pony wall, and split-level bar. |
| `cabinet-45-corner-forensics` | Trace 45° seating and countertop regressions from saved layout through restored state, polygons, and 3D meshes. |
| `cabinet-branch-revert-test` | Test one suspect commit's revert safely in an isolated worktree without merging or deploying. |
| `cabinet-side-by-side-comparison` | Compare the same U-shape and angled peninsula in Designer and Continuous Wall Builder using matched plan/3D evidence. |
| `cabinet-catalog-master-import` | Dry-run, reconcile, audit, and reversibly import catalog master sheets while keeping pricing untouched unless separately authorized. |
| `cabinet-crown-run-continuity` | Verify crown sits on cabinet tops and merges across compatible runs without cutting through fridge bridges or tall cabinets. |
| `cabinet-designer-tablet-ux` | Optimize tablet controls without losing the ordinary cabinet-selection/catalog workflow on wide touch screens. |

**Scope:** This archive contains skills only. It does not contain site source code, customer saved designs, the attached WoodTrac/ClosetTrac PDFs or spreadsheet, or pricing data. Creating the archive does not import data, change the website, or publish a build.
