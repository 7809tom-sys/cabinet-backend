---
name: cabinet-designer-tablet-ux
description: Diagnose and refine Cabinet Dealz regular Designer tablet layouts while preserving the normal cabinet-selection workflow. Use when toolbar overflow, touch breakpoints, catalog drawers, cabinet pickers, 3D controls, or cabinet editor dialogs become unusable on Windows tablets or 1024–1536px CSS viewports.
---

# Cabinet Dealz Designer tablet UX

Read `cabinet-designer-change-workflow` for reproduction, browser proof and checkpointing. This skill covers layout and interaction, not cabinet geometry, pricing, or catalog records.

## Establish the actual screen

1. Measure **CSS viewport**, not physical pixels. A Windows tablet at 1920×1080 and 150% scale may show a ~1280px-wide browser and less vertical height once tabs/taskbar are accounted for. Test real touch and pointer devices at the reported dimensions plus nearby breakpoints (1024, 1280, 1366, 1536 CSS pixels).
2. On the actual regular Designer, record toolbar width, `documentElement.scrollWidth`, canvas size, visible buttons, catalog item count, selected cabinet, and whether a cabinet can be picked and placed. Test Floor Plan and 3D, portrait/landscape when relevant, and keyboard/pointer focus.
3. Inventory duplicate toolbar and 3D-overlay controls. Keep primary Floor Plan/3D, room size, **normal catalog cabinet picker**, material/parts and essential actions discoverable. Move only redundant secondary actions into More, with accessible labels and an obvious escape route.

## Preserve the cabinet-selection method

- On sufficiently wide touch screens, retain the **ordinary desktop catalog/sidebar and cabinet-selection flow**. Do not infer narrow/mobile layout solely from `pointer: coarse` or touch capability; the user may have a 1536px CSS viewport with touch. Let width determine layout tier; use touch only to size tap targets.
- Verify the picker contains actual cabinet results above the fold and stays usable after choosing a door style or switching views. Do not replace the sidebar with a half-height bottom sheet that opens to filters only; the user must see and select cabinets immediately.
- Keep selection, drag/drop, catalog reopening, undo/redo, and cabinet attributes reachable. If a compact drawer is genuinely required at narrow widths, make it large enough, scroll its results independently, preserve current selection, and provide a clear close/restore control.
- An immersive 3D mode must not hide the main app navigation irreversibly. Floating restore controls must respect sheet/dialog stacking so they do not obstruct catalog items or the editor.

## Implementation checkpoints

- Trace `client/src/pages/DesignTool.tsx`, `client/src/components/design/InteractiveRoom3D.tsx`, `client/src/components/TopNav.tsx`, and `client/src/hooks/useTabletWorkspace.ts`. Verify current class names/thresholds rather than copying historical patches.
- Fix the root overflow source (nowrap toolbar, duplicated controls, rigid header) instead of masking horizontal scroll on `html`. Prevent fixed overlays and `z-index` changes from stealing cabinet-picker clicks.
- Make one responsive change at a time; compare a saved design and real catalog response at the same CSS viewport before/after. Never conclude a catalog works because its button opens: **select a cabinet and place it**.
- Run typecheck, focused compact/tablet tests, a production build, and browser interaction checks at all target widths. Confirm no horizontal overflow; screenshots must show the normal picker and actual results. Preserve geometry and saved state; use a versioned checkpoint only after verification, and do not claim live until testing the live origin.
