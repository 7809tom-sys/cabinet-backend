#!/usr/bin/env python3
"""Compare Vitest text logs; exit 1 only for failures new relative to a baseline.

Usage: compare_vitest_failures.py BASELINE_LOG CURRENT_LOG
Accepts full Vitest output or a saved list of lines beginning with ``FAIL``.
This does not replace inspecting the complete logs or checking either run's exit code.
"""

import argparse
import re
from pathlib import Path

ANSI = re.compile(r"\x1b\[[0-9;]*m")
FAIL = re.compile(r"^\s*FAIL\s+(.+?)\s*$")


def failed_tests(path: Path) -> set[str]:
    tests: set[str] = set()
    for raw_line in path.read_text(encoding="utf-8", errors="replace").splitlines():
        line = ANSI.sub("", raw_line)
        match = FAIL.match(line)
        if match:
            tests.add(match.group(1))
    return tests


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("baseline", type=Path, help="Unchanged branch's Vitest log")
    parser.add_argument("current", type=Path, help="Edited branch's Vitest log")
    args = parser.parse_args()
    for path in (args.baseline, args.current):
        if not path.is_file():
            parser.error(f"File not found: {path}")
    before, after = failed_tests(args.baseline), failed_tests(args.current)
    new, resolved = after - before, before - after
    print(f"Baseline failures: {len(before)}; current failures: {len(after)}")
    print(f"New failures: {len(new)}")
    for test in sorted(new):
        print(f"  NEW  {test}")
    print(f"Resolved failures: {len(resolved)}")
    for test in sorted(resolved):
        print(f"  FIXED  {test}")
    if before or after:
        print("Note: A zero comparison exit code does not mean the test suite passes.")
    return 1 if new else 0


if __name__ == "__main__":
    raise SystemExit(main())
